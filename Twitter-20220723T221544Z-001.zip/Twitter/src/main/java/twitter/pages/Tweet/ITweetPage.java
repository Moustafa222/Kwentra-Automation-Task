package twitter.pages.Tweet;

import org.openqa.selenium.By;

public interface ITweetPage {
	By TWEET_TESTBOX = By.xpath("//div[@class=\"public-DraftStyleDefault-block public-DraftStyleDefault-ltr\"]");
	By TWEET_BUTTON = By.xpath("//div[@data-testid='tweetButtonInline']");
	By ADD_PICTURE = By.xpath("//div[@aria-label=\"Add photos or video\"]");
	By FILEPATH = By.xpath("//input[@type='file']");
	By FILE = By.cssSelector("input.file-input");

	void postTweet(String tweet);

	void tweet();

	void add_picture(String file);

	void add_file(String filepath);

}
