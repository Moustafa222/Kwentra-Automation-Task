package twitter.pages.Tweet;

import twitter.pages.BasePage;

public class TweetPage extends BasePage implements ITweetPage {

	@Override
	public void postTweet(String tweet) {
		// TODO Auto-generated method stub
		fillText(TWEET_TESTBOX, tweet);

	}

	@Override
	public void tweet() {
		// TODO Auto-generated method stub

		click(TWEET_BUTTON);

	}

	/*
	 * @Override public void add_file(String filepath) { // TODO Auto-generated
	 * method stub WebDriverWait wait = new WebDriverWait(driver, 100);
	 * fillText(FILE, filepath);
	 * 
	 * }
	 */

	@Override
	public void add_picture(String file) {
		// TODO Auto-generated method stub

		click(ADD_PICTURE);
		fillText(ADD_PICTURE, file);
	}

	@Override
	public void add_file(String filepath) {
		// TODO Auto-generated method stub

	}

}
