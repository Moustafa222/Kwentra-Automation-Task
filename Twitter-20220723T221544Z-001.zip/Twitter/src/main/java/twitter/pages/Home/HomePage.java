package twitter.pages.Home;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.qameta.allure.Step;
import twitter.pages.BasePage;

public class HomePage extends BasePage implements IHomePage {
	private static final Logger logger = LogManager.getLogger(HomePage.class);

	@Override
	@Step
	public void launch(String url) {
		// TODO Auto-generated method stub
		goToUrl(url);
	}

	@Override
	public void openSignIn() {
		// TODO Auto-generated method stub
		click(SIGNIN_BUTTON);
	}

	@Override
	public void enterUsername(String username) {
		// TODO Auto-generated method stub
		fillText(USERNAME_TEXTBOX, username);

	}

	@Override
	public void clickNext() {
		// TODO Auto-generated method stub
		click(NEXT_BUTTON);
	}

	@Override
	public void enterPassword(String password) {
		// TODO Auto-generated method stub
		fillText(PASSWORD_TEXTBOX, password);

	}

	@Override
	public void login() {
		// TODO Auto-generated method stub
		/* click(LOGIN_BUTTON); */
		WebDriverWait wait = new WebDriverWait(driver, 100);
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath(
				"//div[@class='css-901oao r-1awozwy r-jwli3a r-6koalj r-18u37iz r-16y2uox r-37j5jr r-a023e6 r-b88u0q r-1777fci r-rjixqe r-bcqeeo r-q4m81j r-qvutc0']/span/span[contains(text(),\"Log in\")]")))
				.click().build().perform();

		/* actions.build().perform(); */
		// actions.doubleClick();

	}

}
