package twitter.pages.Home;

import org.openqa.selenium.By;

public interface IHomePage {
	By SIGNIN_BUTTON = By.xpath(
			"//div[@class='css-901oao r-1awozwy r-1cvl2hr r-6koalj r-18u37iz r-16y2uox r-37j5jr r-a023e6 r-b88u0q r-1777fci r-rjixqe r-bcqeeo r-q4m81j r-qvutc0']");
	By USERNAME_TEXTBOX = By.xpath("//input[@name='text']");
	By NEXT_BUTTON = By.xpath(
			"//div[@class='css-18t94o4 css-1dbjc4n r-sdzlij r-1phboty r-rs99b7 r-ywje51 r-usiww2 r-2yi16 r-1qi8awa r-1ny4l3l r-ymttw5 r-o7ynqc r-6416eg r-lrvibr r-13qz1uu']");
	By PASSWORD_TEXTBOX = By.xpath("//input[@name=\"password\"]");
	By LOGIN_BUTTON = By.xpath(
			"//div[@class='css-901oao r-1awozwy r-jwli3a r-6koalj r-18u37iz r-16y2uox r-37j5jr r-a023e6 r-b88u0q r-1777fci r-rjixqe r-bcqeeo r-q4m81j r-qvutc0']/span/span[contains(text(),\"Log in\")]");

	void launch(String url);

	void openSignIn();

	void enterUsername(String username);

	void clickNext();

	void enterPassword(String password);

	void login();

}
