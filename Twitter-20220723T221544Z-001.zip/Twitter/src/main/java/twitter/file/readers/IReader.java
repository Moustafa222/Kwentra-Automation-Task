package twitter.file.readers;

public interface IReader {
	default void read() {

	}

	default void read(String filePath) {
	}

}
