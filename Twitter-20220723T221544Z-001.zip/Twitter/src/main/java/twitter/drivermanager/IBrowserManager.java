package twitter.drivermanager;

import org.openqa.selenium.WebDriver;

public interface IBrowserManager {
	WebDriver getDriver();
}
