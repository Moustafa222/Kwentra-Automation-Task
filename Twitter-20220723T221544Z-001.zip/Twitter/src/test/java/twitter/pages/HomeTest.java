package twitter.pages;

import org.testng.annotations.Test;

import twitter.pages.Home.HomePage;

public class HomeTest extends BaseTest {
	@Test
	public void Home() {
		HomePage home = new HomePage();
		home.launch("https://twitter.com/?lang=en");
		home.openSignIn();
		home.enterUsername("AhmedHesham95");
		home.clickNext();
		home.enterPassword("Mysterious123");
		home.login();
	}
}
