package twitter.pages;

import org.testng.annotations.Test;

import twitter.pages.Home.HomePage;
import twitter.pages.Tweet.TweetPage;

public class TweetTest extends BaseTest {
	@Test
	public void tweet() throws InterruptedException {
		HomePage home = new HomePage();
		home.launch("https://twitter.com/?lang=en");/* entering url to launch the browser */
		home.openSignIn();
		home.enterUsername("Moustaf26619392");
		home.clickNext();
		home.enterPassword("Moustafa22");
		home.login();

		TweetPage tweet = new TweetPage();

		tweet.postTweet("Testing on Twitter 123456789 "); /*
															 * Testing that twitter accepts all characters
															 */
		tweet.tweet();

		tweet.postTweet("Testing on Twitter 123456789 "); /* Trying to post the same tweet another time */
		Thread.sleep(50); /* Adding wait to view the action performed ..can be done using explicit wait */
		tweet.tweet();
		Thread.sleep(50);

		tweet.postTweet("https://github.com/"); /* Trying to post a url */
		Thread.sleep(50);
		tweet.tweet();

		tweet.postTweet(
				"https://twitter.com/?lang=en Lorem ipsum dolor sit amet. Ea tenetur delectus ab temporibus commodi sed quia nulla. Id maiores quia et perspiciatis galisum eum adipisci aliquam eum quaerat tempora.\r\n"
						+ "\r\n"
						+ "A voluptate earum non recusandae incidunt qui galisum culpa aut iusto eaque!os eaque assaaaaaaaaaaaaaaaaaaaaaa"); /*
																																				 * posting
																																				 * a
																																				 * tweet
																																				 * more
																																				 * than
																																				 * 280
																																				 * characters
																																				 */
		Thread.sleep(50);
		tweet.tweet();

		tweet.add_picture("screenshot.png");/*
											 * adding a picture in a tweet
											 */
	}

}
